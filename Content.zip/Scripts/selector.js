$(function () {
  $(".icon-check").checkboxradio({
    icon: false
  });
});